package app

func MapUrls() {

}
