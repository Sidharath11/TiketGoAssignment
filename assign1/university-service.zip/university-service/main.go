package main

import (
	"fmt"
	"log"
	"strconv"
	uni "university/model"
)

func main() {
	log.Printf("%s\n", "Application started")

	datastore, err := uni.NewUniverityInfoMongoStore("mongodb://localhost:27017", "University", "UniversityInfo")
	checkerror(err, "connecting to MongoDB")
	defer datastore.Disconnect()

	uni1 := uni.UniverityInfo{University_id: 1, Domain: "chitkara.edu.in", Web_page: "chalkpad.chitkara.edu.in"}
	uni2 := uni.UniverityInfo{University_id: 2, Domain: "chitkara.edu.in", Web_page: "chalkpad.chitkara.edu.in"}
	uni3 := uni.UniverityInfo{University_id: 3, Domain: "chitkara.edu.in", Web_page: "chalkpad.chitkara.edu.in"}
	uni4 := uni.UniverityInfo{University_id: 4, Domain: "chitkara.edu.in", Web_page: "chalkpad.chitkara.edu.in"}
	uni5 := uni.UniverityInfo{University_id: 5, Domain: "chitkara.edu.in", Web_page: "chalkpad.chitkara.edu.in"}

	checkerror(datastore.CreateUniverityInfo(&uni1), "while inserting record")
	checkerror(datastore.CreateUniverityInfo(&uni2), "while inserting record")
	checkerror(datastore.CreateUniverityInfo(&uni3), "while inserting record")
	checkerror(datastore.CreateUniverityInfo(&uni4), "while inserting record")
	checkerror(datastore.CreateUniverityInfo(&uni5), "while inserting record")

	records, err := datastore.ReadAllUniversityInfo()
	for i, val := range records {
		fmt.Printf("%v\n", *val)
		checkerror(err, "While fetching record at "+strconv.Itoa(i))
	}

}

func checkerror(err error, message string) {
	if err != nil {
		log.Printf("error : %s - %s", message, err)
	} else {
		log.Println(message, "done")
	}
}
