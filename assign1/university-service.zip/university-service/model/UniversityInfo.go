package UniversityInformation

type UniverityInfo struct {
	University_id int    `json:"university_id"`
	Domain        string `json:"domain"`
	Web_page      string `json:"web_page"`
}

type UniverityInfoDataStore interface {
	ReadAllUniversityInfo() (alluniinfo []*UniverityInfo, err error)
	CreateUniverityInfo(uniinfo *UniverityInfo) (err error)
	ReadUniversityInfo(uniid int)
	UpdateUniverityInfo(uniinfo *UniverityInfo) (err error)
	DeleteUniversityInfo(uniid int) (err error)
}
