package UniversityInformation

import (
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
)

type UniverityInfoMongoStore struct {
	UniverityInfoDataStore
	DBName         string
	CollectionName string
	Session        *mgo.Session
}

func NewUniverityInfoMongoStore(mongoDBURL, DBName, CollectionName string) (*UniverityInfoMongoStore, error) {

	session, err := ConnectToMongoDB(mongoDBURL)
	if err != nil {
		return nil, err
	}
	return &UniverityInfoMongoStore{
		Session:        session,
		DBName:         DBName,
		CollectionName: CollectionName,
	}, nil
}

func ConnectToMongoDB(mongoDBURL string) (session *mgo.Session, err error) {
	session, err = mgo.Dial(mongoDBURL)
	return
}

func (datastore *UniverityInfoMongoStore) Disconnect() {
	datastore.Session.Close()
}

func (datastore *UniverityInfoMongoStore) ReadAllUniversityInfo() (uniinfos []*UniverityInfo, err error) {
	uniinfocollection := datastore.Session.DB(datastore.DBName).C(datastore.CollectionName)
	err = uniinfocollection.Find(bson.M{}).All(&uniinfos)

	return
}

func (datastore *UniverityInfoMongoStore) CreateUniverityInfo(info *UniverityInfo) (err error) {
	uniinfocollection := datastore.Session.DB(datastore.DBName).C(datastore.CollectionName)
	err = uniinfocollection.Insert(info)
	return
}

func (datastore *UniverityInfoMongoStore) ReadUniversityInfo(id int) (uniinfo *UniverityInfo, err error) {
	uniinfocollection := datastore.Session.DB(datastore.DBName).C(datastore.CollectionName)
	err = uniinfocollection.Find(bson.M{"university_id": id}).One(uniinfo)
	return
}
func (datastore *UniverityInfoMongoStore) UniverityInfo(info *UniverityInfo) (err error) {
	uniinfocollection := datastore.Session.DB(datastore.DBName).C(datastore.CollectionName)
	err = uniinfocollection.Update(bson.M{"university_id": info.University_id}, bson.M{"$set": bson.M{"domain": info.Domain, "web_page": info.Web_page}})
	return
}
func (datastore *UniverityInfoMongoStore) DeleteUniversityInfo(id int) (err error) {
	uniinfocollection := datastore.Session.DB(datastore.DBName).C(datastore.CollectionName)
	err = uniinfocollection.Remove(bson.M{"university_id": id})
	return
}
